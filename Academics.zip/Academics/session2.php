<?php
session_start();
if(!isset($_SESSION['email']) || ($_SESSION['password'] == '')){
	header("location:index.php");
	exit();
}

?>