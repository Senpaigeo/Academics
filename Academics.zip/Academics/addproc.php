<?php
include 'dbclass.php';
$add = new dbclass();
$add -> db_connect();
$add -> select_db();
if(isset($_POST['submit'])){
	$id = $_POST['ID_Num'];
	$ycs = $_POST['YCS'];
	$stu = "Student";
	$ad = $add-> insertStu($id,$ycs,$stu);
if($ad){
	?>
	<script type="text/javascript">
		alert("SUCCeSS");
		window.location = "admissions.php";
	</script>
	<?php
}else{
	?>
	<script type="text/javascript">
		alert("error");
		window.location = "add.php";
	</script>
	<?php
}
}

?>