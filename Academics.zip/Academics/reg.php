<?php
include 'dbclass.php';
$reg = new dbclass();
$reg ->  db_connect();
$reg -> select_db();
if (isset($_POST['submit'])){
	$fn = $_POST['firstName'];
	$ln = $_POST['lastName'];
	$gen = $_POST['gender'];
	$ut = $_POST['userType'];
	$em = $_POST['email'];
	$cn = $_POST['contactnum'];
	$pw = $_POST['password'];

	$plang = $reg-> insert($fn,$ln,$gen,$ut,$em,$cn,$pw);
	if($plang){
		?>
		<script type="text/javascript">
			alert("You've Registered successfully!");
			window.location = "login.php";
		</script>
		<?php
	}else{
		?>
		<script type="text/javascript">
			alert("Fail to enter the data!");
			window.location = "register.php";
		</script>
		<?php
	}
}
?>