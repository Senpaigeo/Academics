<?php
include 'dbclass.php';
$del = new dbclass();
$del -> db_connect();
$del -> select_db();
$del -> sql('DELETE from stud_info where ID_Num = '.$_GET['id'].'');
$dell = $del -> query();
if(!$dell){
	?>
	<script type="text/javascript">
		alert("Success!");
		window.location = "admissions.php";
	</script>
	<?php
}else{
	?>
	<script type="text/javascript">
		alert("error");
		window.location = "admissions.php";
	</script>
	<?php
}
?>
