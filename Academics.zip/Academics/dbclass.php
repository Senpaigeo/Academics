<?php
class dbclass{
	const DB_HOSTNAME = 'localhost';
	const DB_USERNAME= 'root';
	const DB_PASSWORD = '';
	const DB_NAME = 'oop_project';
	protected $_con;
	protected $_sql;
	protected $_result;
	protected $_ins_sql;

	function db_connect(){
		$this->_con = mysqli_connect(self::DB_HOSTNAME, self::DB_USERNAME, self::DB_PASSWORD, self::DB_NAME);
	}
	function select_db(){
		mysqli_select_db($this->_con,self::DB_NAME) or die(mysqli_error($this->_con));
	}
	function sql($query){
		$this->_sql = $query;
		return true;
	}
	function query(){
		$this->_result = mysqli_query($this->_con,$this->_sql);

	}
	function insert($fn,$ln,$gen,$ut,$em,$cn,$pw){
		$this->_sql =mysqli_query($this->_con,"INSERT into accounts (firstName, lastName, gender, userType, email, contactnum, password) VALUES ('$fn','$ln','$gen','$ut','$em','$cn','$pw')");
		return $this->_sql;
		$this->_result = mysqli_connect($this->_con,$this->_sql);
	}
	public function loginT($email,$password){
		$sql = "SELECT * from accounts where email='".$email."' and password='".$password."' and userType='Teacher'";
		$result = mysqli_query($this->_con,$sql);
		if($result->num_rows>0){
			$row = $result->fetch_array();
			return $row['ID'];
		}else{
			return false;
		}
	}
	public function loginS($email,$password){
		$sql = "SELECT * from accounts where email='".$email."' and password='".$password."' and userType='Student'";
		$result = mysqli_query($this->_con,$sql);
		if($result->num_rows>0){
			$row = $result->fetch_array();
			return $row['ID'];
		}else{
			return false;
		}
	}	
	public function insertStu($id,$ycs,$stu){
		$sql = mysqli_query($this->_con,"INSERT INTO `stud_info` (`ID_Num`,`firstName`,`lastName`,`gender`,`Email`,`Year/Course/Section`)
		SELECT accounts.ID,accounts.firstName,accounts.lastName,accounts.gender,accounts.email,'$ycs' from accounts where accounts.ID = '$id' and accounts.userType='$stu'");
		$query = $this->_con->query($sql);
		return true;
	}
	public function insertGr($stn,$sn,$sna,$mg,$tg,$fg){
		$sql = mysqli_query($this->_con,"INSERT INTO grades (stud_id_num,sub_no,sub_name,Mid_grade,triF_grade,final_grade) values ('$stn','$sn','$sna','$mg','$tg','$fg')");
		$query = $this->_con->query($sql);
		return true;
	}
	function upStu($in,$fn,$ln,$gen,$em,$ycs){
	$sql = mysqli_query($this->_con,"UPDATE `stud_info` SET `firstName`='$fn', `lastName`='$ln',`gender`='$gen',`Email`='$em', `Year/Course/Section` = '$ycs' WHERE `ID_Num` = '$in'");
	$query = $this->_con->query($sql);
	return true;
	}
		function upGr($in,$fn,$ln,$gen,$em,$ycs){
	$sql = mysqli_query($this->_con,"UPDATE grades SET stud_id_num='$in', sub_name='$ln',Mid_grade='$gen',triF_grade='$em', final_grade = '$ycs' WHERE sub_no = '$fn'");
	$query = $this->_con->query($sql);
	return true;
	}
	public function fetch_stu(){
		while($this->_row = mysqli_fetch_array($this->_result,MYSQLI_ASSOC)){
			$in = $this->_row['ID_Num'];
			$fn = $this->_row['firstName'];
			$ln = $this->_row['lastName'];
			$gen = $this->_row['gender'];
			$em = $this->_row['Email'];
			$ycs = $this->_row['Year/Course/Section'];
			echo "<tr><td>";
			echo $in;
			echo "</td>";
			echo "<td>";
			echo $fn;
			echo "</td>";
			echo "<td>";
			echo $ln;
			echo "</td>";
			echo "<td>";
			echo $gen;
			echo "</td>";
			echo "<td>";
			echo $em;
			echo "</td>";
			echo "<td>";
			echo $ycs;
			echo "</td>";
			echo '<td> <a href="edit.php?action=edit & id='.$this->_row['ID_Num'].'" class="btn btn-primary">Edit</a>
			<a href="drop.php?action=delete & id='.$this->_row['ID_Num'].'" class="btn btn-danger">Drop</a></td>';

		}

	}
		public function fetch_grade_st(){
		while($this->_row = mysqli_fetch_array($this->_result,MYSQLI_ASSOC)){
			$in = $this->_row['stud_id_num'];
			$fn = $this->_row['sub_no'];
			$ln = $this->_row['sub_name'];
			$gen = $this->_row['Mid_grade'];
			$em = $this->_row['triF_grade'];
			$ycs = $this->_row['final_grade'];
			echo "<tr><td>";
			echo $in;
			echo "</td>";
			echo "<td>";
			echo $fn;
			echo "</td>";
			echo "<td>";
			echo $ln;
			echo "</td>";
			echo "<td>";
			echo $gen;
			echo "</td>";
			echo "<td>";
			echo $em;
			echo "</td>";
			echo "<td>";
			echo $ycs;
			echo "</td>";
			echo '<td> <a href="editGr.php?action=edit & id='.$this->_row['sub_no'].'" class="btn btn-primary">Edit</a>
			<a href="delGrade.php?action=delete & id='.$this->_row['sub_no'].'" class="btn btn-danger">Drop</a></td>';

		}

	}
	public function fetch_grade_stud(){
		while($this->_row = mysqli_fetch_array($this->_result,MYSQLI_ASSOC)){
			$in = $this->_row['stud_id_num'];
			$fn = $this->_row['sub_no'];
			$ln = $this->_row['sub_name'];
			$gen = $this->_row['Mid_grade'];
			$em = $this->_row['triF_grade'];
			$ycs = $this->_row['final_grade'];
			echo "<tr><td>";
			echo $in;
			echo "</td>";
			echo "<td>";
			echo $fn;
			echo "</td>";
			echo "<td>";
			echo $ln;
			echo "</td>";
			echo "<td>";
			echo $gen;
			echo "</td>";
			echo "<td>";
			echo $em;
			echo "</td>";
			echo "<td>";
			echo $ycs;
			echo "</td>";

		}
	}
			public function fegrade_stu(){
		while($this->_row = mysqli_fetch_array($this->_result,MYSQLI_ASSOC)){
			$in = $this->_row['ID_Num'];
			$fn = $this->_row['firstName'];
			$ln = $this->_row['lastName'];
			$gen = $this->_row['gender'];
			$em = $this->_row['Email'];
			$ycs = $this->_row['Year/Course/Section'];
			echo "<tr><td>";
			echo $in;
			echo "</td>";
			echo "<td>";
			echo $fn;
			echo "</td>";
			echo "<td>";
			echo $ln;
			echo "</td>";
			echo "<td>";
			echo $gen;
			echo "</td>";
			echo "<td>";
			echo $em;
			echo "</td>";
			echo "<td>";
			echo $ycs;
			echo "</td>";
			echo '<td> <a href="edit.php?action=edit & id='.$this->_row['ID_Num'].'" class="btn btn-primary">Edit</a>
			<a href="drop.php?action=delete & id='.$this->_row['ID_Num'].'" class="btn btn-danger">Drop</a></td>';

		}

	}public function fetch_stu_frm(){
		while($this->_row = mysqli_fetch_array($this->_result,MYSQLI_ASSOC)){
			$in = $this->_row['ID_Num'];
			$fn = $this->_row['firstName'];
			$ln = $this->_row['lastName'];
			$gen = $this->_row['gender'];
			$em = $this->_row['Email'];
			$ycs = $this->_row['Year/Course/Section'];
			?>
	<form action="update_stu.php" method="POST">
                        <div class="col-md-12 form-group">
                            <label for="ID_Num">ID NUMBER</label>
                            <input type="number" id="ID_Num" name="ID_Num" class="form-control form-control-lg" value="<?php echo $in?>" readonly>
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="firstName">First Name</label>
                            <input type="text" id="firstName" name="firstName" class="form-control form-control-lg" value="<?php echo $fn?>">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="lastName">Last Name</label>
                            <input type="text" id="lastName" name="lastName" class="form-control form-control-lg" value="<?php echo $ln?>">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="gender">Gender</label>
                            <input type="text" id="gender" name="gender" class="form-control form-control-lg" value="<?php echo $gen?>">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="Email">Email</label>
                            <input type="email" id="Email" name="Email" class="form-control form-control-lg" value="<?php echo $em?>">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="Year/Course/Section">Year/Course/Section</label>
                            <input type="text" id="Year/Course/Section" name="YCS" class="form-control form-control-lg" value="<?php echo $ycs?>">
                        </div>
                                            </div>
                    <div class="row">
                        <div class="col-12">
                            <input type="submit" name="submit" value="update" class="btn btn-primary btn-lg px-5">
                        </div>
                    </div>
                </div>
              </form>
		
		<?php
	}
	}
	public function fetch_gr_frm(){
		while($this->_row = mysqli_fetch_array($this->_result,MYSQLI_ASSOC)){
			$in = $this->_row['stud_id_num'];
			$fn = $this->_row['sub_no'];
			$ln = $this->_row['sub_name'];
			$gen = $this->_row['Mid_grade'];
			$em = $this->_row['triF_grade'];
			$ycs = $this->_row['final_grade'];
			?>
	<form action="updategr.php" method="POST">
                        <div class="col-md-12 form-group">
                            <label for="ID_Num">STUDENT NUMBER</label>
                            <input type="number" id="ID_Num" name="stud_id_num" class="form-control form-control-lg" value="<?php echo $in?>" readonly>
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="firstName">SUBJECT NUMBER</label>
                            <input type="number" id="firstName" name="sub_no" class="form-control form-control-lg" value="<?php echo $fn?>">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="lastName">SUBJECT NAME</label>
                            <input type="text" id="lastName" name="sub_name" class="form-control form-control-lg" value="<?php echo $ln?>">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="gender">MIDTERM GRADE</label>
                            <input type="number" id="gender" name="Mid_grade" class="form-control form-control-lg" value="<?php echo $gen?>">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="Email">TRIAL FINAL GRADE</label>
                            <input type="number" id="Email" name="triF_grade" class="form-control form-control-lg" value="<?php echo $em?>">
                        </div>
                        <div class="col-md-12 form-group">
                            <label for="Year/Course/Section">FINAL GRADE</label>
                            <input type="number" id="Year/Course/Section" name="final_grade" class="form-control form-control-lg" value="<?php echo $ycs?>" readonly>
                        </div>
                                            </div>
                    <div class="row">
                        <div class="col-12">
                            <input type="submit" name="submit" value="update" class="btn btn-primary btn-lg px-5">
                        </div>
                    </div>
                </div>
              </form>
		
		<?php
	}
	}
}
?>