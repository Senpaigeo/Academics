<?php
include 'dbclass.php';
$del = new dbclass();
$del -> db_connect();
$del -> select_db();
$del -> sql('DELETE from grades where sub_no = '.$_GET['id'].'');
$dell = $del -> query();
if(!$dell){
	?>
	<script type="text/javascript">
		alert("SUCCeSS!");
		window.location = "courses.php";
	</script>
	<?php
}else{
	?>
	<script type="text/javascript">
		alert("error");
		window.location = "courses.php";
	</script>
	<?php
}
?>
