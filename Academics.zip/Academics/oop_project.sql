-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 23, 2019 at 09:52 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oop_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `ID` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `userType` enum('Administrator','Student','Teacher') NOT NULL,
  `email` varchar(50) NOT NULL,
  `contactnum` int(11) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`ID`, `firstName`, `lastName`, `gender`, `userType`, `email`, `contactnum`, `password`) VALUES
(11, 'admin', 'admin', 'Male', 'Teacher', 'admin@admin', 2147483647, 'admin'),
(12, 'Moharif', 'Solaiman', 'Male', 'Student', 'Mgsolaiman@yahoo.com', 2147483647, '321'),
(13, 'solaiman', 'solaiman', 'Male', 'Teacher', 'solaiman@solaiman', 2147483647, 'teacher'),
(14, 'nam', 'nam', 'Female', 'Student', 'nam@nam', 2147483647, '54321'),
(15, 'admin', 'admin', 'Male', 'Teacher', 'admin@admin', 2147483647, 'admin'),
(16, 'Moharif', 'solai', 'Male', 'Student', 'Mgsolaiman@yahoo.com', 13658975, 'student'),
(17, 'Diana Rose', 'nam', 'Female', 'Student', 'dianarosebancal@gmail.com', 2147483647, 'password');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `stud_id_num` int(5) NOT NULL,
  `sub_no` varchar(10) NOT NULL,
  `sub_name` varchar(15) NOT NULL,
  `Mid_grade` double(99,2) NOT NULL,
  `triF_grade` double(99,2) NOT NULL,
  `final_grade` double(99,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`stud_id_num`, `sub_no`, `sub_name`, `Mid_grade`, `triF_grade`, `final_grade`) VALUES
(14, '121', 'cs121', 87.00, 93.00, 90.00);

-- --------------------------------------------------------

--
-- Table structure for table `stud_info`
--

CREATE TABLE `stud_info` (
  `ID_Num` int(11) NOT NULL,
  `firstName` varchar(11) NOT NULL,
  `lastName` varchar(11) NOT NULL,
  `gender` enum('Male','Female') NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Year/Course/Section` enum('1/BSCS/A','1/BSCS/B','2/BSCS/A','2/BSCS/B') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stud_info`
--

INSERT INTO `stud_info` (`ID_Num`, `firstName`, `lastName`, `gender`, `Email`, `Year/Course/Section`) VALUES
(14, 'makin', 'nam', 'Female', 'nam@nam', '2/BSCS/A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`stud_id_num`);

--
-- Indexes for table `stud_info`
--
ALTER TABLE `stud_info`
  ADD PRIMARY KEY (`ID_Num`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
