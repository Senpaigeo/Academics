<?php
include 'dbclass.php';
$add = new dbclass();
$add -> db_connect();
$add -> select_db();
if(isset($_POST['submit'])){
	$stn = $_POST['stud_id_num'];
	$sn = $_POST['sub_no'];
	$sna = $_POST['sub_name'];
	$mg = $_POST['Mid_grade'];
	$tg = $_POST['triF_grade'];
	$fn = ($_POST['Mid_grade'] + $_POST['triF_grade'])/2;
	$ad = $add-> insertGr($stn,$sn,$sna,$mg,$tg,$fn);
if($ad){
	?>
	<script type="text/javascript">
		alert("Success");
		window.location = "courses.php";
	</script>
	<?php
}else{
	?>
	<script type="text/javascript">
		alert("Error");
		window.location = "addGrades.php";
	</script>
	<?php
}
}

?>