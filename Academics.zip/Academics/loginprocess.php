<?php
include 'dbclass.php';
include 'session.php';
$login = new dbclass();
$login -> db_connect();
$login -> select_db();
if(isset($_POST['submit'])){
	$email = $_POST['email'];
	$password = $_POST['password'];

	$teacher = $login->loginT($email,$password);
	$student = $login->loginS($email,$password);

	if($_SESSION['user']=$teacher){
		?>
		<script type="text/javascript">
			alert("Welcome teacher");
			window.location = "index.php";
		</script>
		<?php
	}elseif($_SESSION['user']=$student){
		?>
		<script type="text/javascript">
			alert("Welcome student");
			window.location = "studentdirect.php";
		</script>
		<?php
	}else{
			?>
		<script type="text/javascript">
			alert("Email or Password is not registered");
			window.location = "logout.php";
		</script>
		<?php

	}
}else{
	echo "error";
}
?>