<?php
                      include 'dbclass.php';
                      $update = new dbclass();
                      $update -> db_connect();
                      $update -> select_db();
                      if(isset($_POST['submit'])){
                      	$in = $_POST['ID_Num'];
                      	$fn = $_POST['firstName'];
                      	$ln = $_POST['lastName'];
                      	$gen = $_POST['gender'];
                      	$em = $_POST['Email'];
                      	$ycs = $_POST['YCS'];

                      $up = $update->upStu($in,$fn,$ln,$gen,$em,$ycs);
                     if($up){
                     	?>
                     	<script type="text/javascript">
                     		alert("success");
                     		window.location = "admissions.php"
                     	</script>
                     	<?php
                     }else{
                     	?>
                     	<script type="text/javascript">
                     		alert("error");
                     		window.location = "edit.php"
                     	</script>
                     	<?php
                     }
}
?>