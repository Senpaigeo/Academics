<?php
session_start();
function loggin(){
	return isset($_SESSION['user']);
}
function confirm_login(){
	if(!loggin()){
		?>
		<script type="text/javascript">
			window.location = "login.php";
		</script>
		<?php
	}
}
?>